// State variables
let attemptCount = 0;
let photoIndex = 0;
let lyricIndex = 0;
let openedHearts = new Set();

// Create floating hearts background
function createFloatingHearts() {
    const heartBg = document.getElementById('heartBg');
    const hearts = ['❤️', '💕', '💖', '💗', '💓', '💝'];
    
    setInterval(() => {
        const heart = document.createElement('div');
        heart.className = 'heart';
        heart.innerText = hearts[Math.floor(Math.random() * hearts.length)];
        heart.style.left = Math.random() * 100 + '%';
        heart.style.animationDuration = (Math.random() * 3 + 5) + 's';
        heart.style.fontSize = (Math.random() * 15 + 15) + 'px';
        heartBg.appendChild(heart);
        
        setTimeout(() => heart.remove(), 8000);
    }, 800);
}

// Move the "No" button to a random position
function moveButton() {
    const noBtn = document.getElementById('noBtn');     
    const gifElement = document.getElementById('statusGif');
    const counter = document.getElementById('attemptCounter');
    
    attemptCount++;
    counter.style.display = 'flex';
    counter.innerText = attemptCount;
    counter.style.animation = 'bounce 0.5s ease-in-out';
    
    noBtn.style.position = 'fixed'; 
    
    const padding = 50;
    const x = Math.random() * (window.innerWidth - noBtn.offsetWidth - padding * 2) + padding;
    const y = Math.random() * (window.innerHeight - noBtn.offsetHeight - padding * 2) + padding;
    
    noBtn.style.left = x + 'px';
    noBtn.style.top = y + 'px';
    noBtn.style.transition = 'all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55)';

    const randomIndex = Math.floor(Math.random() * gifs.length);
    gifElement.src = gifPath + gifs[randomIndex];

    showNotification();
    
    const yesBtn = document.getElementById('yesBtn');
    const currentScale = 1 + (attemptCount * 0.05);
    yesBtn.style.transform = `scale(${Math.min(currentScale, 1.5)})`;
}

// Show notification message
function showNotification() {
    const container = document.getElementById('notifContainer');
    const notif = document.createElement('div');
    notif.className = 'notification';
    notif.innerText = messages[Math.floor(Math.random() * messages.length)];
    container.appendChild(notif);

    setTimeout(() => {
        notif.style.animation = "fadeOut 0.6s forwards";
        setTimeout(() => notif.remove(), 600);
    }, 2500);
}

// Create confetti effect
function createConfetti() {
    const colors = ['#ff4d6d', '#ff6b9d', '#ffa4c0', '#ffccd5', '#fff0f5'];
    const confettiCount = 100;
    
    for (let i = 0; i < confettiCount; i++) {
        setTimeout(() => {
            const confetti = document.createElement('div');
            confetti.className = 'confetti';
            confetti.style.left = Math.random() * 100 + '%';
            confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
            confetti.style.transform = `rotate(${Math.random() * 360}deg)`;
            confetti.style.animationDelay = Math.random() * 0.5 + 's';
            document.body.appendChild(confetti);
            
            setTimeout(() => confetti.remove(), 3000);
        }, i * 20);
    }
}

// Create a floating photo in the gallery
function createFloatingPhoto() {
    const gallery = document.getElementById('photoGallery');
    const photo = document.createElement('img');
    photo.className = 'floating-photo';
    photo.src = photos[photoIndex % photos.length];
    
    // Random position
    const x = 20 + Math.random() * 60; // 20-80% of screen width
    const y = 20 + Math.random() * 60; // 20-80% of screen height
    photo.style.left = x + '%';
    photo.style.top = y + '%';
    
    // Random size
    const size = 250 + Math.random() * 200; // 250-450px
    photo.style.maxWidth = size + 'px';
    photo.style.maxHeight = size + 'px';
    
    // Random animation duration
    const duration = 12 + Math.random() * 6; // 12-18 seconds
    photo.style.animationDuration = duration + 's';
    
    // Random delay
    const delay = Math.random() * 2;
    photo.style.animationDelay = delay + 's';
    
    gallery.appendChild(photo);
    
    // Remove after animation completes
    setTimeout(() => {
        photo.remove();
    }, (duration + delay) * 1000);
    
    photoIndex++;
}

// Create floating hearts in the photo gallery
function createGalleryHearts() {
    const gallery = document.getElementById('photoGallery');
    const hearts = ['💕', '❤️', '💖', '💗', '💓', '💝', '💘', '💞'];
    
    setInterval(() => {
        const heart = document.createElement('div');
        heart.className = 'gallery-heart';
        heart.innerText = hearts[Math.floor(Math.random() * hearts.length)];
        heart.style.left = Math.random() * 100 + '%';
        heart.style.fontSize = (Math.random() * 20 + 20) + 'px';
        heart.style.animationDuration = (Math.random() * 4 + 8) + 's';
        heart.style.animationDelay = Math.random() * 2 + 's';
        
        gallery.appendChild(heart);
        
        setTimeout(() => heart.remove(), 12000);
    }, 1500);
}

// Update the lyrics display
function updateLyrics() {
    const lyricsDisplay = document.getElementById('lyricsDisplay');
    
    lyricsDisplay.innerText = lyrics[lyricIndex];
    
    // If we've reached the last message, keep it visible and show proceed button
    if (lyricIndex >= lyrics.length - 1) {
        lyricsDisplay.style.animation = 'none';
        lyricsDisplay.style.opacity = '1';
        lyricsDisplay.style.transform = 'translateX(-50%) translateY(0)';
        
        // Show proceed button after 3 seconds
        setTimeout(() => {
            const proceedButton = document.getElementById('proceedButton');
            proceedButton.classList.add('visible');
        }, 3000);
        return;
    }
    
    lyricIndex++;
}

// Transition from photo gallery to interactive heart
function transitionToInteractiveHeart() {
    const photoGallery = document.getElementById('photoGallery');
    const interactiveHeart = document.getElementById('interactiveHeart');
    const proceedButton = document.getElementById('proceedButton');
    
    // Hide proceed button
    proceedButton.style.opacity = '0';
    
    // Fade out photo gallery
    photoGallery.style.transition = 'opacity 2s ease-out';
    photoGallery.style.opacity = '0';
    
    setTimeout(() => {
        photoGallery.style.display = 'none';
        interactiveHeart.classList.add('active');
        
        // Generate the hearts grid
        generateHeartsGrid();
    }, 2000);
}

// Generate the grid of clickable hearts
function generateHeartsGrid() {
    const heartsGrid = document.getElementById('heartsGrid');
    heartsGrid.innerHTML = '';
    
    for (let i = 0; i < loveReasons.length; i++) {
        const heartItem = document.createElement('div');
        heartItem.className = 'heart-item';
        heartItem.setAttribute('data-index', i);
        heartItem.onclick = () => openHeart(i);
        
        const heartIcon = document.createElement('div');
        heartIcon.className = 'heart-icon';
        heartIcon.innerText = '❤️';
        
        const heartNumber = document.createElement('div');
        heartNumber.className = 'heart-number';
        heartNumber.innerText = `#${i + 1}`;
        
        heartItem.appendChild(heartIcon);
        heartItem.appendChild(heartNumber);
        heartsGrid.appendChild(heartItem);
    }
}

// Open a specific heart and show its reason
function openHeart(index) {
    const heartItem = document.querySelectorAll('.heart-item')[index];
    const reasonModal = document.getElementById('reasonModal');
    const reasonModalText = document.getElementById('reasonModalText');
    
    // Mark as opened
    if (!openedHearts.has(index)) {
        openedHearts.add(index);
        heartItem.classList.add('opened');
        updateHeartsProgress();
    }
    
    // Show the reason in modal
    reasonModalText.innerText = loveReasons[index];
    reasonModal.classList.add('show');
    
    // Add animation to heart
    heartItem.classList.add('opened');
}

// Close the reason modal
function closeReasonModal() {
    const reasonModal = document.getElementById('reasonModal');
    reasonModal.classList.remove('show');
}

// Update the progress counter
function updateHeartsProgress() {
    const heartsProgress = document.getElementById('heartsProgress');
    heartsProgress.innerText = `${openedHearts.size} / ${loveReasons.length} hearts opened`;
    
    // Special message when all opened
    if (openedHearts.size === loveReasons.length) {
        heartsProgress.innerText = `All ${loveReasons.length} hearts opened! 💖 You've seen them all!`;
        heartsProgress.style.background = 'linear-gradient(135deg, #ff4d6d 0%, #ff6b9d 100%)';
        heartsProgress.style.transform = 'translateX(-50%) scale(1.1)';
        
        // Create celebration confetti
        createConfetti();
    }
}


// Main celebration function when "Yes" is clicked
function celebrate() {
    createConfetti();
    
    const questionContainer = document.getElementById('questionContainer');
    questionContainer.style.transition = 'opacity 1.5s ease-out';
    questionContainer.style.opacity = '0';
    
    // Stop creating background hearts
    const heartBg = document.getElementById('heartBg');
    heartBg.style.display = 'none';
    
    setTimeout(() => {
        questionContainer.style.display = 'none';
        const photoGallery = document.getElementById('photoGallery');
        const musicControls = document.getElementById('musicControls');
        
        photoGallery.classList.add('active');
        musicControls.classList.add('active');
        
        // Auto-play music
        const audio = document.getElementById('backgroundMusic');
        audio.play().catch(e => {
            console.log('Auto-play prevented. User needs to click play button.');
        });
        
        // Start creating floating photos
        createFloatingPhoto();
        setInterval(createFloatingPhoto, 5000);
        
        // Start creating floating hearts in gallery
        createGalleryHearts();
        
        // Update lyrics every 6 seconds
        updateLyrics();
        setInterval(() => {
            updateLyrics();
        }, 6000);
        
    }, 1500);
}

// Music controls - toggle play/pause
function toggleMusic() {
    const audio = document.getElementById('backgroundMusic');
    const btn = document.getElementById('playPauseBtn');
    
    if (audio.paused) {
        audio.play();
        btn.innerText = '⏸';
    } else {
        audio.pause();
        btn.innerText = '▶';
    }
}

// Restart music from beginning
function restartMusic() {
    const audio = document.getElementById('backgroundMusic');
    audio.currentTime = 0;
    audio.play();
    document.getElementById('playPauseBtn').innerText = '⏸';
}

// Initialize floating hearts when page loads
window.addEventListener('load', () => {
    createFloatingHearts();
});
