// Messages that appear when "No" button is clicked
const messages = [
    "AWWW DI MO KO LOVE?! 💔", 
    "KAWAWA NAMAN AKOOOO! 😢", 
    "HAYSSS! 😞", 
    "NO LOVE AT ALL 🥺", 
    "SAKITT!! 💔", 
    "PLEASE NAMAN! 🙏",
    "SERYOSO KA BA? 😭",
    "HUHU MAHAL KITA! 💕"
];

// GIF filenames (located in images/gif/ folder)
const gifs = [
    "1.gif", 
    "2.gif", 
    "3.gif", 
    "4.gif", 
    "5.gif", 
    "6.gif", 
    "7.gif", 
    "8.gif", 
    "9.gif", 
    "10.gif"
];

const gifPath = "images/gif/"; 

// Photo paths for the celebration gallery
const photos = [
    'photos/photo1.jpg',
    'photos/photo2.jpg',
    'photos/photo3.jpg',
    'photos/photo4.jpg',
    'photos/photo5.jpg',
    'photos/photo6.jpg',
    'photos/photo7.jpg',
    'photos/photo8.jpg',
    'photos/photo9.jpg',
    'photos/photo10.jpg',
    'photos/photo11.jpg',
    'photos/photo12.jpg',
    'photos/photo13.jpg',
    'photos/photo14.jpg',
    'photos/photo15.jpg',
    'photos/photo16.jpg',
    'photos/photo17.jpg',
    'photos/photo18.jpg',
    'photos/photo19.jpg',
    'photos/photo20.jpg',
    'photos/photo21.jpg',
    'photos/photo22.jpg',
    'photos/photo23.jpg',
    'photos/photo24.jpg',
    'photos/photo25.jpg',
    'photos/photo26.jpg'
];

// Lyrics/messages that will display during the photo gallery
const lyrics = [
    "Hello Love ❤️",
    "Happy Valentines Day 💕",
    "Sana na surprise kita dito hehe basahin mo to.. 😊",
    "First of all gusto ko mag thank you sayo sa love at tiwala na binibigay mo sakin.",
    "Thank you for making me happy and feel special thru the years we are together.",
    "I hope it last until the very end. 💖",
    "Thank you sa full support na ginagawa mo sakin at sa pasensya na binigay mo.",
    "Thank you sa time and efforts na binigay mo sa relationship natin.",
    "Thank you sa mga sacrifices na ginawa mo para sakin.",
    "Love na love kita wag ka mag alala beb di kita pababayaan. 💕",
    "Kasama kita nung time na nangangarap pa lang ako.",
    "Sisiguraduhin ko ikaw pa din kasama ko hanggang maabot lahat ng yun at kasama ka.",
    "I love you beb Happy Valentines 💖" // This will be the last message that stays
];

// Reasons why I love you (for interactive heart section)
const loveReasons = [
    "Because your smile lights up my entire world 😊",
    "Because you make every ordinary day feel special ✨",
    "Because you believe in me even when I doubt myself 💪",
    "Because your laugh is my favorite sound 🎵",
    "Because you understand me without words 💭",
    "Because you're my best friend and my love ❤️",
    "Because you make me want to be a better person 🌟",
    "Because your hugs feel like home 🏠",
    "Because you're beautiful inside and out 💖",
    "Because you're always there when I need you 🤗",
    "Because you support my dreams 🎯",
    "Because your kindness inspires me 🌸",
    "Because you make me laugh even on tough days 😄",
    "Because you're patient with my flaws 💝",
    "Because you care about the little things 🌺",
    "Because you make me feel loved every day 💕",
    "Because you're my safe place 🛡️",
    "Because your eyes sparkle when you're happy ✨",
    "Because you never give up on us 💪",
    "Because you make life an adventure 🎢",
    "Because you're thoughtful and caring 🌹",
    "Because you accept me for who I am 🦋",
    "Because you make the future exciting 🌈",
    "Because you're my favorite person 👑",
    "Because loving you feels so natural 🌿",
    "Because you bring out the best in me 🌟",
    "Because you're loyal and trustworthy 💎",
    "Because you make sacrifices for us 🙏",
    "Because you're strong and brave 💪",
    "Because you're my partner in everything 🤝",
    "Because you make me feel appreciated 🌸",
    "Because you're creative and inspiring 🎨",
    "Because you listen when I need to talk 👂",
    "Because you celebrate my wins with me 🎉",
    "Because you comfort me when I'm down 🤗",
    "Because you're genuine and real 💯",
    "Because you make me feel secure 🔒",
    "Because you're passionate about life 🔥",
    "Because you're generous with your love 💝",
    "Because you're my greatest blessing 🙏",
    "Because you make every moment memorable 📸",
    "Because you're wise beyond your years 🦉",
    "Because you're fun and spontaneous 🎊",
    "Because you have a beautiful soul 👼",
    "Because you're my forever and always 💍",
    "Because you complete me in every way 🧩",
    "Because you're irreplaceable 💖",
    "Because you're the love of my life 💕",
    "Because I choose you today and every day ❤️",
    "Because you're simply YOU, and that's perfect 🌟"
];
